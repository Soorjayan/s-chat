const express = require("express");
const { register, login, getMe, logout, changePassword, deleteAccount } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();
router.post("/register", register);
router.post("/login", login);
router.get("/me", protect, getMe);
router.post("/logout", protect, logout);
router.put("/password", protect, changePassword);
router.delete("/account", protect, deleteAccount);

module.exports = router;
