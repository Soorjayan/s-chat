const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { createGroup, updateGroup, leaveGroup } = require("../controllers/groupController");

router.use(protect);
router.post("/", createGroup);
router.put("/:id", updateGroup);
router.post("/:id/leave", leaveGroup);

module.exports = router;
