const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");
const { getConversations, createPrivateConversation, getMessages, sendMessage, sendFileMessage, markAsRead } = require("../controllers/conversationController");

router.use(protect);
router.get("/", getConversations);
router.post("/private/:userId", createPrivateConversation);
router.get("/:id/messages", getMessages);
router.post("/:id/messages", sendMessage);
router.post("/:id/messages/file", upload.single("file"), sendFileMessage);
router.patch("/:id/read", markAsRead);

module.exports = router;
