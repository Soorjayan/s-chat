const User = require("../models/User");

const getUsers = async (req, res) => {
    try {
        const search = req.query.search?.trim() || "";

        const filter = {
            _id: { $ne: req.user._id },
        };

        if (search) {
            filter.$or = [
                { name: { $regex: search, $options: "i" } },
                { email: { $regex: search, $options: "i" } },
            ];
        }

        const users = await User.find(filter)
            .select("-password")
            .sort({ name: 1 })
            .limit(50);

        res.json({
            success: true,
            count: users.length,
            users,
        });
    } catch (error) {
        console.error("Get users error:", error);

        res.status(500).json({
            success: false,
            message: "Unable to fetch users.",
        });
    }
};

const getUserById = async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select("-password");

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User not found.",
            });
        }

        res.json({
            success: true,
            user,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to fetch user.",
        });
    }
};

const updateProfile = async (req, res) => {
    try {
        const { name, profilePicture } = req.body;

        if (name !== undefined) {
            if (!name.trim()) {
                return res.status(400).json({
                    success: false,
                    message: "Name cannot be empty.",
                });
            }

            req.user.name = name.trim();
        }

        if (profilePicture !== undefined) {
            req.user.profilePicture = profilePicture;
        }

        await req.user.save();

        res.json({
            success: true,
            message: "Profile updated successfully.",
            user: req.user,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Unable to update profile.",
        });
    }
};

module.exports = {
    getUsers,
    getUserById,
    updateProfile,
};
