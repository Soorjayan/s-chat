const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");

const generateToken = (userId) => jwt.sign(
    { userId },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
);

const register = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        if (!name || !email || !password) return res.status(400).json({ success: false, message: "Name, email and password are required." });
        if (password.length < 6) return res.status(400).json({ success: false, message: "Password must contain at least 6 characters." });
        const normalizedEmail = email.trim().toLowerCase();
        const existingUser = await User.findOne({ email: normalizedEmail });
        if (existingUser) return res.status(409).json({ success: false, message: "An account with this email already exists." });
        const hashedPassword = await bcrypt.hash(password, 12);
        const user = await User.create({ name: name.trim(), email: normalizedEmail, password: hashedPassword });
        const token = generateToken(user._id);
        res.status(201).json({ success: true, message: "Registration successful.", token, user: { id: user._id, name: user.name, email: user.email, profilePicture: user.profilePicture, status: user.status } });
    } catch (error) {
        console.error("Register error:", error);
        res.status(500).json({ success: false, message: "Server error during registration." });
    }
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ success: false, message: "Email and password are required." });
        const normalizedEmail = email.trim().toLowerCase();
        const user = await User.findOne({ email: normalizedEmail }).select("+password");
        if (!user) return res.status(401).json({ success: false, message: "Invalid email or password." });
        const passwordMatches = await bcrypt.compare(password, user.password);
        if (!passwordMatches) return res.status(401).json({ success: false, message: "Invalid email or password." });
        user.status = "online";
        user.lastSeen = new Date();
        await user.save();
        const token = generateToken(user._id);
        res.json({ success: true, message: "Login successful.", token, user: { id: user._id, name: user.name, email: user.email, profilePicture: user.profilePicture, status: user.status, lastSeen: user.lastSeen } });
    } catch (error) {
        console.error("Login error:", error);
        res.status(500).json({ success: false, message: "Server error during login." });
    }
};

const getMe = async (req, res) => res.json({ success: true, user: req.user });

const logout = async (req, res) => {
    try {
        await User.findByIdAndUpdate(req.user._id, { status: "offline", lastSeen: new Date() });
        res.json({ success: true, message: "Logged out successfully." });
    } catch (error) {
        res.status(500).json({ success: false, message: "Server error during logout." });
    }
};

const changePassword = async (req, res) => {
    try {
        const { currentPassword, newPassword } = req.body;
        if (!currentPassword || !newPassword) return res.status(400).json({ success: false, message: "Current password and new password are required." });
        if (newPassword.length < 6) return res.status(400).json({ success: false, message: "New password must contain at least 6 characters." });
        const user = await User.findById(req.user._id).select("+password");
        const matches = await bcrypt.compare(currentPassword, user.password);
        if (!matches) return res.status(401).json({ success: false, message: "Current password is incorrect." });
        user.password = await bcrypt.hash(newPassword, 12);
        await user.save();
        res.json({ success: true, message: "Password changed successfully." });
    } catch (error) {
        console.error("Change password error:", error);
        res.status(500).json({ success: false, message: "Unable to change password." });
    }
};

const deleteAccount = async (req, res) => {
    try {
        const { password } = req.body;
        if (!password) return res.status(400).json({ success: false, message: "Password is required to delete the account." });
        const user = await User.findById(req.user._id).select("+password");
        if (!user) return res.status(404).json({ success: false, message: "User not found." });
        const matches = await bcrypt.compare(password, user.password);
        if (!matches) return res.status(401).json({ success: false, message: "Incorrect password." });

        const userId = user._id;
        const sentMessages = await Message.find({ sender: userId }).select("_id");
        const sentMessageIds = sentMessages.map((message) => message._id);
        await Message.deleteMany({ sender: userId });

        if (sentMessageIds.length) {
            await Conversation.updateMany(
                { lastMessage: { $in: sentMessageIds } },
                { $set: { lastMessage: null } }
            );
        }

        // Remove the account from conversations. Private conversations are deleted;
        // group conversations remain for other members with this account removed.
        await Conversation.deleteMany({ type: "private", members: userId });
        await Conversation.updateMany(
            { type: "group", members: userId },
            { $pull: { members: userId } }
        );
        await Conversation.deleteMany({ members: { $size: 0 } });
        await User.findByIdAndDelete(userId);

        res.json({ success: true, message: "Account and associated chat data were deleted." });
    } catch (error) {
        console.error("Delete account error:", error);
        res.status(500).json({ success: false, message: "Unable to delete account." });
    }
};

module.exports = { register, login, getMe, logout, changePassword, deleteAccount };
