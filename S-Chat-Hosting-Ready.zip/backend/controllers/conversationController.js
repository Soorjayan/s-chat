const mongoose = require("mongoose");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const User = require("../models/User");

const isMember = (conversation, userId) =>
    conversation.members.some((member) => member.toString() === userId.toString());

const populateConversation = (query) =>
    query.populate("members", "name email profilePicture status lastSeen")
        .populate({ path: "lastMessage", populate: { path: "sender", select: "name" } });

const getConversations = async (req, res) => {
    try {
        const conversations = await populateConversation(
            Conversation.find({ members: req.user._id }).sort({ updatedAt: -1 })
        );
        const enriched = await Promise.all(conversations.map(async (conversation) => {
            const unreadCount = await Message.countDocuments({
                conversation: conversation._id,
                sender: { $ne: req.user._id },
                status: { $ne: "read" },
            });
            const item = conversation.toObject();
            item.unreadCount = unreadCount;
            return item;
        }));
        res.json({ success: true, conversations: enriched });
    } catch (error) {
        console.error("Get conversations error:", error);
        res.status(500).json({ success: false, message: "Unable to fetch conversations." });
    }
};

const createPrivateConversation = async (req, res) => {
    try {
        const otherUserId = req.params.userId;
        if (!mongoose.isValidObjectId(otherUserId)) {
            return res.status(400).json({ success: false, message: "Invalid user ID." });
        }
        if (otherUserId.toString() === req.user._id.toString()) {
            return res.status(400).json({ success: false, message: "You cannot chat with yourself." });
        }

        const User = require("../models/User");
        const otherUser = await User.findById(otherUserId).select("name email profilePicture status lastSeen");
        if (!otherUser) return res.status(404).json({ success: false, message: "User not found." });

        let conversation = await Conversation.findOne({
            type: "private",
            members: { $all: [req.user._id, otherUserId], $size: 2 },
        });

        if (!conversation) {
            conversation = await Conversation.create({
                type: "private",
                members: [req.user._id, otherUserId],
                createdBy: req.user._id,
            });
        }

        conversation = await populateConversation(Conversation.findById(conversation._id));
        res.status(200).json({ success: true, conversation });
    } catch (error) {
        console.error("Create private conversation error:", error);
        res.status(500).json({ success: false, message: "Unable to create conversation." });
    }
};

const getMessages = async (req, res) => {
    try {
        const { id } = req.params;
        if (!mongoose.isValidObjectId(id)) return res.status(400).json({ success: false, message: "Invalid conversation ID." });
        const conversation = await Conversation.findById(id);
        if (!conversation) return res.status(404).json({ success: false, message: "Conversation not found." });
        if (!isMember(conversation, req.user._id)) return res.status(403).json({ success: false, message: "You are not a member of this conversation." });

        const limit = Math.min(Number(req.query.limit) || 100, 200);
        const messages = await Message.find({ conversation: id })
            .sort({ createdAt: -1 })
            .limit(limit)
            .populate("sender", "name email profilePicture");

        await Message.updateMany(
            { conversation: id, sender: { $ne: req.user._id }, status: { $ne: "read" } },
            { $set: { status: "read" } }
        );

        res.json({ success: true, messages: messages.reverse() });
    } catch (error) {
        console.error("Get messages error:", error);
        res.status(500).json({ success: false, message: "Unable to fetch messages." });
    }
};

const classifyFile = (file) => {
    const mime = (file.mimetype || "").toLowerCase();
    const ext = require("path").extname(file.originalname).toLowerCase();
    if (mime.startsWith("image/")) return "image";
    if (mime.startsWith("video/")) return "video";
    if ([".zip", ".rar"].includes(ext)) return "zip";
    if ([".pdf", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".txt"].includes(ext)) return "document";
    return "file";
};


const markOnlineRecipientsDelivered = async (conversation, message, io) => {
    const recipientIds = conversation.members.filter((memberId) => memberId.toString() !== message.sender.toString());
    const onlineRecipients = await User.find({ _id: { $in: recipientIds }, status: "online" }).select("_id");
    if (!onlineRecipients.length) return false;
    if (message.status === "sent") {
        message.status = "delivered";
        await message.save();
    }
    if (io) io.to(`conversation_${conversation._id}`).emit("message_delivered", { messageId: message._id.toString(), conversationId: conversation._id.toString() });
    return true;
};

const sendFileMessage = async (req, res) => {
    try {
        const { id } = req.params;
        if (!mongoose.isValidObjectId(id)) return res.status(400).json({ success: false, message: "Invalid conversation ID." });
        if (!req.file) return res.status(400).json({ success: false, message: "No file was uploaded." });
        const conversation = await Conversation.findById(id);
        if (!conversation) return res.status(404).json({ success: false, message: "Conversation not found." });
        if (!isMember(conversation, req.user._id)) return res.status(403).json({ success: false, message: "You are not a member of this conversation." });

        const baseUrl = `${req.protocol}://${req.get("host")}`;
        const fileUrl = `${baseUrl}/uploads/${req.file.filename}`;
        const message = await Message.create({
            conversation: id, sender: req.user._id, text: (req.body.text || "").trim(),
            messageType: classifyFile(req.file), fileUrl, fileName: req.file.originalname,
            fileSize: req.file.size, status: "sent"
        });
        conversation.lastMessage = message._id;
        await conversation.save();
        const populatedMessage = await Message.findById(message._id).populate("sender", "name email profilePicture");
        const io = req.app.get("io");
        if (io) {
            io.to(`conversation_${id}`).emit("new_message", populatedMessage);
            conversation.members.forEach((memberId) => io.to(`user_${memberId}`).emit("conversation_updated", { conversationId: id }));
        }
        await markOnlineRecipientsDelivered(conversation, message, io);
        res.status(201).json({ success: true, message: populatedMessage });
    } catch (error) {
        console.error("Send file message error:", error);
        res.status(500).json({ success: false, message: "Unable to send file message." });
    }
};

const sendMessage = async (req, res) => {
    try {
        const { id } = req.params;
        const text = (req.body.text || "").trim();
        const messageType = req.body.messageType || "text";
        if (!mongoose.isValidObjectId(id)) return res.status(400).json({ success: false, message: "Invalid conversation ID." });
        if (!text) return res.status(400).json({ success: false, message: "Message cannot be empty." });
        if (!["text", "emoji"].includes(messageType)) return res.status(400).json({ success: false, message: "This endpoint currently supports text and emoji messages." });

        const conversation = await Conversation.findById(id);
        if (!conversation) return res.status(404).json({ success: false, message: "Conversation not found." });
        if (!isMember(conversation, req.user._id)) return res.status(403).json({ success: false, message: "You are not a member of this conversation." });

        const message = await Message.create({ conversation: id, sender: req.user._id, text, messageType, status: "sent" });
        conversation.lastMessage = message._id;
        await conversation.save();

        const populatedMessage = await Message.findById(message._id).populate("sender", "name email profilePicture");
        const io = req.app.get("io");
        if (io) {
            io.to(`conversation_${id}`).emit("new_message", populatedMessage);
            conversation.members.forEach((memberId) => {
                io.to(`user_${memberId}`).emit("conversation_updated", { conversationId: id });
            });
        }

        res.status(201).json({ success: true, message: populatedMessage });
    } catch (error) {
        console.error("Send message error:", error);
        res.status(500).json({ success: false, message: "Unable to send message." });
    }
};

const markAsRead = async (req, res) => {
    try {
        const conversation = await Conversation.findById(req.params.id);
        if (!conversation) return res.status(404).json({ success: false, message: "Conversation not found." });
        if (!isMember(conversation, req.user._id)) return res.status(403).json({ success: false, message: "You are not a member of this conversation." });
        await Message.updateMany({ conversation: conversation._id, sender: { $ne: req.user._id } }, { $set: { status: "read" } });
        const io = req.app.get("io");
        if (io) io.to(`conversation_${conversation._id}`).emit("messages_read", { conversationId: conversation._id.toString(), userId: req.user._id.toString() });
        res.json({ success: true });
    } catch (error) {
        console.error("Mark read error:", error);
        res.status(500).json({ success: false, message: "Unable to mark messages as read." });
    }
};

module.exports = { getConversations, createPrivateConversation, getMessages, sendMessage, sendFileMessage, markAsRead };
