const mongoose = require("mongoose");
const Conversation = require("../models/Conversation");
const User = require("../models/User");

const populateGroup = (query) =>
    query.populate("members", "name email profilePicture status lastSeen")
        .populate({ path: "lastMessage", populate: { path: "sender", select: "name" } });

const createGroup = async (req, res) => {
    try {
        const name = (req.body.name || "").trim();
        let memberIds = Array.isArray(req.body.memberIds) ? req.body.memberIds : [];
        if (!name) return res.status(400).json({ success: false, message: "Group name is required." });
        if (name.length > 100) return res.status(400).json({ success: false, message: "Group name is too long." });

        memberIds = [...new Set(memberIds.map(String).filter((id) => mongoose.isValidObjectId(id)))];
        if (memberIds.length < 1) return res.status(400).json({ success: false, message: "Select at least one other member." });
        if (memberIds.includes(req.user._id.toString())) memberIds = memberIds.filter((id) => id !== req.user._id.toString());

        const users = await User.find({ _id: { $in: memberIds } }).select("_id name email profilePicture status lastSeen");
        if (users.length !== memberIds.length) return res.status(400).json({ success: false, message: "One or more selected users do not exist." });

        const conversation = await Conversation.create({
            type: "group",
            name,
            members: [req.user._id, ...memberIds],
            createdBy: req.user._id,
        });

        const populated = await populateGroup(Conversation.findById(conversation._id));
        const io = req.app.get("io");
        if (io) {
            populated.members.forEach((member) => io.to(`user_${member._id}`).emit("conversation_created", populated));
        }
        res.status(201).json({ success: true, conversation: populated });
    } catch (error) {
        console.error("Create group error:", error);
        res.status(500).json({ success: false, message: "Unable to create group." });
    }
};

const updateGroup = async (req, res) => {
    try {
        const conversation = await Conversation.findById(req.params.id);
        if (!conversation || conversation.type !== "group") return res.status(404).json({ success: false, message: "Group not found." });
        if (conversation.createdBy.toString() !== req.user._id.toString()) return res.status(403).json({ success: false, message: "Only the group creator can update this group." });

        if (req.body.name !== undefined) {
            const name = String(req.body.name).trim();
            if (!name) return res.status(400).json({ success: false, message: "Group name cannot be empty." });
            conversation.name = name.slice(0, 100);
        }
        if (Array.isArray(req.body.memberIds)) {
            const ids = [...new Set(req.body.memberIds.map(String).filter((id) => mongoose.isValidObjectId(id)))];
            const users = await User.find({ _id: { $in: ids } }).select("_id");
            if (users.length !== ids.length) return res.status(400).json({ success: false, message: "One or more users do not exist." });
            conversation.members = [req.user._id, ...ids.filter((id) => id !== req.user._id.toString())];
        }
        await conversation.save();
        const populated = await populateGroup(Conversation.findById(conversation._id));
        const io = req.app.get("io");
        if (io) populated.members.forEach((member) => io.to(`user_${member._id}`).emit("conversation_updated", { conversationId: conversation._id.toString() }));
        res.json({ success: true, conversation: populated });
    } catch (error) {
        console.error("Update group error:", error);
        res.status(500).json({ success: false, message: "Unable to update group." });
    }
};

const leaveGroup = async (req, res) => {
    try {
        const conversation = await Conversation.findById(req.params.id);
        if (!conversation || conversation.type !== "group") return res.status(404).json({ success: false, message: "Group not found." });
        if (!conversation.members.some((id) => id.toString() === req.user._id.toString())) return res.status(403).json({ success: false, message: "You are not a member of this group." });
        conversation.members = conversation.members.filter((id) => id.toString() !== req.user._id.toString());
        if (conversation.members.length === 0) await conversation.deleteOne();
        else {
            if (conversation.createdBy.toString() === req.user._id.toString()) conversation.createdBy = conversation.members[0];
            await conversation.save();
        }
        res.json({ success: true, message: "You left the group." });
    } catch (error) {
        console.error("Leave group error:", error);
        res.status(500).json({ success: false, message: "Unable to leave group." });
    }
};

module.exports = { createGroup, updateGroup, leaveGroup };
