const uploadFile = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: "No file was uploaded.",
            });
        }

        const baseUrl = `${req.protocol}://${req.get("host")}`;

        res.status(201).json({
            success: true,
            message: "File uploaded successfully.",
            file: {
                originalName: req.file.originalname,
                fileName: req.file.filename,
                size: req.file.size,
                mimeType: req.file.mimetype,
                url: `${baseUrl}/uploads/${req.file.filename}`,
            },
        });
    } catch (error) {
        console.error("Upload error:", error);

        res.status(500).json({
            success: false,
            message: "File upload failed.",
        });
    }
};

module.exports = { uploadFile };
