const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const http = require("http");
const path = require("path");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const User = require("./models/User");
const connectDB = require("./config/db");

dotenv.config();

const app = express();
const server = http.createServer(app);
app.set("trust proxy", 1); // Respect HTTPS/proxy headers on Render.

const configuredOrigins = (process.env.CLIENT_URL || "http://localhost:5173")
    .split(",")
    .map((origin) => origin.trim().replace(/\/$/, ""))
    .filter(Boolean);
const corsOptions = {
    origin(origin, callback) {
        // Requests without an Origin (health checks, command-line clients) are allowed.
        if (!origin || configuredOrigins.includes(origin.replace(/\/$/, ""))) return callback(null, true);
        return callback(new Error("Origin is not allowed by CORS"));
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    credentials: true,
};

const io = new Server(server, { cors: corsOptions });
app.set("io", io);
app.use(cors(corsOptions));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.get("/", (req, res) => res.json({ success: true, message: "S Chat API is running." }));
app.get("/api/health", (req, res) => {
    const databaseConnected = mongoose.connection.readyState === 1;
    res.status(databaseConnected ? 200 : 503).json({
        success: databaseConnected,
        message: databaseConnected ? "Server and database are healthy." : "Server is running but database is unavailable.",
        database: databaseConnected ? "connected" : "disconnected",
    });
});

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/users", require("./routes/userRoutes"));
app.use("/api/conversations", require("./routes/conversationRoutes"));
app.use("/api/groups", require("./routes/groupRoutes"));
app.use("/api/uploads", require("./routes/uploadRoutes"));

app.use((err, req, res, next) => {
    if (res.headersSent) return next(err);
    if (err.message === "Origin is not allowed by CORS") {
        return res.status(403).json({ success: false, message: "This website is not allowed to access the API." });
    }
    if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(413).json({ success: false, message: "File is too large. Maximum size is 50 MB." });
    }
    console.error("Unhandled request error:", err);
    return res.status(500).json({ success: false, message: "An unexpected server error occurred." });
});

if (!process.env.MONGO_URI) {
    console.error("Missing required environment variable: MONGO_URI");
    process.exit(1);
}
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error("JWT_SECRET is required and must be at least 32 characters long.");
    process.exit(1);
}

io.use((socket, next) => {
    try {
        const token = socket.handshake.auth?.token;
        if (!token) return next(new Error("Authentication required"));
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        socket.userId = decoded.userId;
        next();
    } catch (error) {
        next(new Error("Invalid authentication token"));
    }
});

const activeSockets = new Map();
io.on("connection", async (socket) => {
    const userId = socket.userId.toString();
    socket.join(`user_${userId}`);
    activeSockets.set(userId, (activeSockets.get(userId) || 0) + 1);
    try {
        const now = new Date();
        await User.findByIdAndUpdate(userId, { status: "online", lastSeen: now });
        io.emit("user_status", { userId, status: "online", lastSeen: now });
    } catch (error) {
        console.error("Online status error:", error.message);
    }
    console.log(`Socket connected: ${socket.id} for user ${userId}`);

    socket.on("join_conversation", (conversationId) => {
        if (conversationId) socket.join(`conversation_${conversationId}`);
    });
    socket.on("leave_conversation", (conversationId) => {
        if (conversationId) socket.leave(`conversation_${conversationId}`);
    });
    socket.on("typing", ({ conversationId, isTyping }) => {
        if (conversationId) socket.to(`conversation_${conversationId}`).emit("typing", { conversationId, userId, isTyping: !!isTyping });
    });
    socket.on("message_delivered", async ({ conversationId, messageId }) => {
        if (!conversationId || !messageId) return;
        try {
            const Message = require("./models/Message");
            const message = await Message.findOneAndUpdate(
                { _id: messageId, conversation: conversationId, status: "sent" },
                { $set: { status: "delivered" } },
                { new: true }
            );
            if (message) io.to(`conversation_${conversationId}`).emit("message_delivered", { messageId, conversationId, userId });
        } catch (error) {
            console.error("Delivery status error:", error.message);
        }
    });
    socket.on("disconnect", async () => {
        const remaining = Math.max((activeSockets.get(userId) || 1) - 1, 0);
        if (remaining) {
            activeSockets.set(userId, remaining);
            return;
        }
        activeSockets.delete(userId);
        try {
            const lastSeen = new Date();
            await User.findByIdAndUpdate(userId, { status: "offline", lastSeen });
            io.emit("user_status", { userId, status: "offline", lastSeen });
        } catch (error) {
            console.error("Offline status error:", error.message);
        }
        console.log(`Socket disconnected: ${socket.id}`);
    });
});

const PORT = Number(process.env.PORT) || 5000;
const start = async () => {
    try {
        await connectDB();
        server.listen(PORT, "0.0.0.0", () => console.log(`S Chat API listening on port ${PORT}`));
    } catch (error) {
        console.error("Startup failed:", error.message);
        process.exit(1);
    }
};

const shutdown = (signal) => {
    console.log(`${signal} received. Shutting down gracefully.`);
    server.close(() => {
        mongoose.connection.close(false).finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(1), 10000).unref();
};
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
start();
