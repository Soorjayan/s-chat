# Chat Application - Backend

Backend foundation for the Real-Time Chat Application.

## Stack

- Node.js
- Express.js
- MongoDB
- Mongoose
- Socket.io
- JWT
- bcryptjs
- Multer

## Setup

```bash
npm install
```

Copy `.env.example` to `.env` and configure:

```env
PORT=5000
MONGO_URI=your_mongodb_atlas_connection_string
JWT_SECRET=your_secret
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

## Run

Development:

```bash
npm run dev
```

Production:

```bash
npm start
```

## Current API

### Authentication

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/logout`

### Users

- `GET /api/users?search=name`
- `GET /api/users/:id`
- `PUT /api/users/profile`

### Uploads

- `POST /api/uploads`

The upload endpoint expects multipart/form-data with the field name `file`.

### Health

- `GET /api/health`

## Socket.io foundation

Current socket events:

- `join_user`
- `join_conversation`
- `leave_conversation`

Real-time message events will be implemented in the next development phase.
