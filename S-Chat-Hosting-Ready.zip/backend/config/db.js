const mongoose = require("mongoose");

const connectDB = async () => {
    const uri = process.env.MONGO_URI;
    if (!uri) throw new Error("MONGO_URI environment variable is missing.");
    mongoose.set("strictQuery", true);
    const conn = await mongoose.connect(uri, {
        serverSelectionTimeoutMS: 15000,
    });
    console.log(`MongoDB connected: ${conn.connection.host}`);
    return conn;
};

module.exports = connectDB;
