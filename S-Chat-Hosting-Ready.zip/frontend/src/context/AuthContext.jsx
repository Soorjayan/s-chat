import { createContext, useContext, useEffect, useState } from "react";
import api from "../services/api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [token, setToken] = useState(localStorage.getItem("chat_token"));
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadUser = async () => {
            if (!token) {
                setLoading(false);
                return;
            }

            try {
                const response = await api.get("/auth/me", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setUser(response.data.user);
            } catch {
                localStorage.removeItem("chat_token");
                setToken(null);
                setUser(null);
            } finally {
                setLoading(false);
            }
        };

        loadUser();
    }, [token]);

    const login = async (email, password) => {
        const response = await api.post("/auth/login", { email, password });
        localStorage.setItem("chat_token", response.data.token);
        setToken(response.data.token);
        setUser(response.data.user);
        return response.data;
    };

    const register = async (name, email, password) => {
        const response = await api.post("/auth/register", {
            name,
            email,
            password,
        });
        localStorage.setItem("chat_token", response.data.token);
        setToken(response.data.token);
        setUser(response.data.user);
        return response.data;
    };

    const updateUser = (nextUser) => setUser(nextUser);

    const logout = async () => {
        try {
            if (token) {
                await api.post(
                    "/auth/logout",
                    {},
                    { headers: { Authorization: `Bearer ${token}` } }
                );
            }
        } catch (error) {
            console.error("Logout error:", error);
        } finally {
            localStorage.removeItem("chat_token");
            setToken(null);
            setUser(null);
        }
    };

    return (
        <AuthContext.Provider
            value={{ user, token, loading, login, register, updateUser, logout }}
        >
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);