import axios from "axios";

// Set VITE_API_URL in Vercel to your deployed backend URL ending in /api.
// The localhost fallback is only for local development.
const api = axios.create({
    baseURL: (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace(/\/$/, ""),
    headers: {
        "Content-Type": "application/json",
    },
});

export default api;
