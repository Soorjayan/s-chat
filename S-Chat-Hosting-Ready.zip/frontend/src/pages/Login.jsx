import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Login = () => {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError("");
        if (!email || !password) { setError("Please enter email and password."); return; }
        try { setLoading(true); await login(email, password); navigate("/dashboard", { replace: true }); }
        catch (error) { setError(error.response?.data?.message || "Login failed."); }
        finally { setLoading(false); }
    };

    return <main className="auth-page auth-page-redesign">
        <aside className="auth-visual" aria-hidden="true">
                <div className="auth-visual-glow" />
                <div className="auth-scene-bubble auth-scene-bubble-left"><span>•••</span><small>Say hello!</small></div>
                <div className="auth-phone"><div className="auth-phone-notch"/><div className="auth-phone-head">S Chat <span>●</span></div><div className="auth-phone-user"><b>RS</b><span><strong>Rohit</strong><small>Online now</small></span></div><div className="auth-phone-msg auth-phone-msg-left">Hey! How's it going?</div><div className="auth-phone-msg auth-phone-msg-right">All good! ⚡</div><div className="auth-phone-msg auth-phone-msg-left short">Great 😊</div><div className="auth-phone-input"><span>Message...</span><b>➤</b></div></div>
                <div className="auth-scene-bubble auth-scene-bubble-right">⚡</div>
                <div className="auth-visual-copy"><h2>Every conversation<br/>starts with a hello.</h2><p>Connect, share, and stay close with S Chat.</p><div className="auth-visual-pills"><span>⚡ Real-time chat</span><span>🔒 Private conversations</span></div></div>
            </aside>
        <section className="auth-card auth-card-redesign">
            <div className="s-chat-auth-brand"><span className="s-chat-auth-mark"><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M7 10.5A7.5 7.5 0 0 1 14.5 3h21A7.5 7.5 0 0 1 43 10.5v15a7.5 7.5 0 0 1-7.5 7.5H21l-10 8v-9.5A7.5 7.5 0 0 1 7 24.5z" fill="currentColor"/><text x="11.5" y="28" fontSize="22" fontWeight="950" fill="#fff">S</text><path d="M33 15 24 28h6l-2 10 11-15h-7z" fill="#ffd329"/></svg></span><span>S Chat</span></div>
            <h1>Welcome Back</h1>
            <p className="subtitle">Login to your S Chat account</p>
            {error && <div className="error-message" role="alert">{error}</div>}
            <form onSubmit={handleSubmit}>
                <label htmlFor="email">Email</label>
                <input id="email" type="email" placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
                <label htmlFor="password">Password</label>
                <input id="password" type="password" placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
                <button type="submit" disabled={loading}>{loading ? "Logging in..." : "Login"}</button>
            </form>
            <p className="switch-text">Don't have an account? <Link to="/register">Create Account</Link></p>
            <p className="auth-privacy-note"><span>🔒</span> Your conversations, your space.</p>
        </section>
    </main>;
};

export default Login;
