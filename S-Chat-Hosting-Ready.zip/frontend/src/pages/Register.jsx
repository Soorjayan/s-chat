import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Register = () => {
    const { register } = useAuth();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({ name: "", email: "", password: "" });
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const handleChange = (event) => setFormData({ ...formData, [event.target.name]: event.target.value });
    const handleSubmit = async (event) => {
        event.preventDefault(); setError("");
        if (!formData.name || !formData.email || !formData.password) { setError("Please fill in all fields."); return; }
        try { setLoading(true); await register(formData.name, formData.email, formData.password); navigate("/dashboard", { replace: true }); }
        catch (error) { setError(error.response?.data?.message || "Registration failed."); }
        finally { setLoading(false); }
    };
    return <main className="auth-page auth-page-redesign auth-register-page">
        <aside className="auth-visual" aria-hidden="true">
                <div className="auth-visual-glow" />
                <div className="auth-scene-bubble auth-scene-bubble-left"><span>•••</span><small>Say hello!</small></div>
                <div className="auth-phone"><div className="auth-phone-notch"/><div className="auth-phone-head">S Chat <span>●</span></div><div className="auth-phone-user"><b>RS</b><span><strong>Rohit</strong><small>Online now</small></span></div><div className="auth-phone-msg auth-phone-msg-left">Hey! How's it going?</div><div className="auth-phone-msg auth-phone-msg-right">All good! ⚡</div><div className="auth-phone-msg auth-phone-msg-left short">Great 😊</div><div className="auth-phone-input"><span>Message...</span><b>➤</b></div></div>
                <div className="auth-scene-bubble auth-scene-bubble-right">⚡</div>
                <div className="auth-visual-copy"><h2>Every conversation<br/>starts with a hello.</h2><p>Connect, share, and stay close with S Chat.</p><div className="auth-visual-pills"><span>⚡ Real-time chat</span><span>🔒 Private conversations</span></div></div>
            </aside>
        <section className="auth-card auth-card-redesign">
            <div className="s-chat-auth-brand"><span className="s-chat-auth-mark"><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M7 10.5A7.5 7.5 0 0 1 14.5 3h21A7.5 7.5 0 0 1 43 10.5v15a7.5 7.5 0 0 1-7.5 7.5H21l-10 8v-9.5A7.5 7.5 0 0 1 7 24.5z" fill="currentColor"/><text x="11.5" y="28" fontSize="22" fontWeight="950" fill="#fff">S</text><path d="M33 15 24 28h6l-2 10 11-15h-7z" fill="#ffd329"/></svg></span><span>S Chat</span></div>
            <h1>Create Account</h1>
            <p className="subtitle">Join S Chat and start connecting</p>
            {error && <div className="error-message" role="alert">{error}</div>}
            <form onSubmit={handleSubmit}>
                <label htmlFor="name">Full Name</label>
                <input id="name" type="text" name="name" placeholder="Enter your full name" value={formData.name} onChange={handleChange} autoComplete="name" required />
                <label htmlFor="email">Email</label>
                <input id="email" type="email" name="email" placeholder="Enter your email" value={formData.email} onChange={handleChange} autoComplete="email" required />
                <label htmlFor="password">Password</label>
                <input id="password" type="password" name="password" placeholder="Create a password (at least 6 characters)" value={formData.password} onChange={handleChange} autoComplete="new-password" minLength={6} required />
                <button type="submit" disabled={loading}>{loading ? "Creating Account..." : "Create Account"}</button>
            </form>
            <p className="switch-text">Already have an account? <Link to="/login">Login</Link></p>
            <p className="auth-privacy-note"><span>⚡</span> Good conversations start here.</p>
        </section>
    </main>;
};

export default Register;
