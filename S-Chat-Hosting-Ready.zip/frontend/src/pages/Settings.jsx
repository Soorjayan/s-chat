import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

const auth = (token) => ({ headers: { Authorization: `Bearer ${token}` } });

const getInitials = (name = "User") => name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("");

const Settings = () => {
    const { user, token, updateUser, logout } = useAuth();
    const navigate = useNavigate();
    const [name, setName] = useState(user?.name || "");
    const [profilePicture, setProfilePicture] = useState(user?.profilePicture || "");
    const [photoFile, setPhotoFile] = useState(null);
    const [photoPreview, setPhotoPreview] = useState(user?.profilePicture || "");
    const photoInputRef = useRef(null);
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [deletePassword, setDeletePassword] = useState("");
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");
    const [saving, setSaving] = useState(false);
    const [deleting, setDeleting] = useState(false);

    const clearNotice = () => { setMessage(""); setError(""); };

    const saveProfile = async (event) => {
        event.preventDefault(); clearNotice();
        try {
            setSaving(true);
            let nextProfilePicture = profilePicture;
            if (photoFile) {
                const formData = new FormData();
                formData.append("file", photoFile);
                const uploadResponse = await api.post("/uploads", formData, {
                    headers: { Authorization: `Bearer ${token}`, "Content-Type": "multipart/form-data" }
                });
                nextProfilePicture = uploadResponse.data.file.url;
            }
            const response = await api.put("/users/profile", { name, profilePicture: nextProfilePicture }, auth(token));
            setProfilePicture(response.data.user.profilePicture || "");
            setPhotoPreview(response.data.user.profilePicture || "");
            setPhotoFile(null);
            updateUser(response.data.user);
            setMessage("Profile updated successfully.");
        } catch (err) {
            setError(err.response?.data?.message || "Unable to update profile.");
        } finally { setSaving(false); }
    };

    const savePassword = async (event) => {
        event.preventDefault(); clearNotice();
        if (newPassword !== confirmPassword) return setError("New password and confirmation do not match.");
        try {
            setSaving(true);
            const response = await api.put("/auth/password", { currentPassword, newPassword }, auth(token));
            setMessage(response.data.message);
            setCurrentPassword(""); setNewPassword(""); setConfirmPassword("");
        } catch (err) {
            setError(err.response?.data?.message || "Unable to change password.");
        } finally { setSaving(false); }
    };

    const deleteAccount = async (event) => {
        event.preventDefault(); clearNotice();
        const confirmed = window.confirm("Delete your account permanently? Your profile, messages you sent, and private conversations will be deleted. This cannot be undone.");
        if (!confirmed) return;
        try {
            setDeleting(true);
            const response = await api.delete("/auth/account", { ...auth(token), data: { password: deletePassword } });
            localStorage.removeItem("chat_token");
            setMessage(response.data.message);
            await logout();
        } catch (err) {
            setError(err.response?.data?.message || "Unable to delete account.");
        } finally { setDeleting(false); }
    };

    return (
        <div className="settings-page">
            <header className="settings-header">
                <button className="back-btn" onClick={() => navigate("/dashboard")}>← Back to Chat</button>
                <div className="settings-brand"><span className="s-chat-logo"><svg viewBox="0 0 48 48" aria-hidden="true"><path className="logo-bubble" d="M7 10.5A7.5 7.5 0 0 1 14.5 3h21A7.5 7.5 0 0 1 43 10.5v15a7.5 7.5 0 0 1-7.5 7.5H21l-10 8v-9.5A7.5 7.5 0 0 1 7 24.5z"/><text className="logo-letter" x="12" y="27">S</text><path className="logo-bolt" d="M33 18 25 28h5l-1 8 9-12h-6z"/></svg></span> S Chat</div>
                <div className="settings-user"><div className="header-avatar">{user?.profilePicture ? <img src={user.profilePicture} alt={user.name} /> : getInitials(user?.name)}</div><span>{user?.name}</span></div>
            </header>

            <main className="settings-content">
                <div className="settings-title"><h1>Settings</h1><p>Manage your profile, password and account.</p></div>
                {message && <div className="settings-success">✓ {message}</div>}
                {error && <div className="settings-error">{error}</div>}

                <section className="settings-card">
                    <div className="settings-card-heading"><div className="settings-icon">👤</div><div><h2>Profile</h2><p>Update the information other users see.</p></div></div>
                    <form onSubmit={saveProfile} className="settings-form">
                        <label>Display name<input value={name} onChange={(e) => setName(e.target.value)} required /></label>
                        <div className="profile-photo-editor">
                            <div className="profile-photo-preview">{photoPreview ? <img src={photoPreview} alt="Profile preview" /> : <span>{getInitials(name)}</span>}</div>
                            <div className="profile-photo-actions">
                                <input ref={photoInputRef} type="file" accept="image/png,image/jpeg,image/jpg,image/webp,image/gif" className="hidden-file-input" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; if (file.size > 5 * 1024 * 1024) { setError("Profile photo must be 5 MB or smaller."); return; } setPhotoFile(file); setPhotoPreview(URL.createObjectURL(file)); setProfilePicture(""); }} />
                                <button type="button" className="secondary-btn" onClick={() => photoInputRef.current?.click()}>📷 Add Photo</button>
                                <small>JPG, PNG, GIF or WebP · Max 5 MB</small>
                            </div>
                        </div>
                        <label>Profile photo URL <span className="optional">(optional)</span><input value={profilePicture} onChange={(e) => { setProfilePicture(e.target.value); setPhotoFile(null); setPhotoPreview(e.target.value); }} placeholder="Or paste an image URL" /></label>
                        <button className="primary-settings-btn" disabled={saving}>{saving ? "Saving..." : "Save Profile"}</button>
                    </form>
                </section>

                <section className="settings-card">
                    <div className="settings-card-heading"><div className="settings-icon">🔐</div><div><h2>Change Password</h2><p>Use a strong password with at least 6 characters.</p></div></div>
                    <form onSubmit={savePassword} className="settings-form">
                        <label>Current password<input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} required /></label>
                        <label>New password<input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} minLength={6} required /></label>
                        <label>Confirm new password<input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} minLength={6} required /></label>
                        <button className="primary-settings-btn" disabled={saving}>{saving ? "Updating..." : "Change Password"}</button>
                    </form>
                </section>

                <section className="settings-card danger-card">
                    <div className="settings-card-heading"><div className="settings-icon danger">⚠️</div><div><h2>Delete Account</h2><p>This permanently removes your account and associated chat data.</p></div></div>
                    <form onSubmit={deleteAccount} className="settings-form">
                        <label>Confirm with your password<input type="password" value={deletePassword} onChange={(e) => setDeletePassword(e.target.value)} required /></label>
                        <div className="danger-note">This action cannot be undone. Your messages will be removed, and you will be signed out.</div>
                        <button className="delete-account-btn" disabled={deleting}>{deleting ? "Deleting..." : "Delete My Account"}</button>
                    </form>
                </section>
            </main>
        </div>
    );
};

export default Settings;
