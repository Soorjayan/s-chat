import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { io } from "socket.io-client";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

// Set VITE_SOCKET_URL in Vercel to your deployed backend origin.
const SOCKET_URL = (import.meta.env.VITE_SOCKET_URL || "http://localhost:5000").replace(/\/$/, "");
const emojis = ["😀", "😂", "😍", "😊", "👍", "❤️", "🔥", "🎉", "😎", "🙏"];
const getInitials = (name = "User") => name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("");
const auth = (token) => ({ headers: { Authorization: `Bearer ${token}` } });
const SChatLogo = ({ compact = false }) => (
    <span className={`s-chat-logo ${compact ? "compact" : ""}`} aria-hidden="true">
        <svg viewBox="0 0 48 48" role="img">
            <path className="logo-bubble" d="M7 10.5A7.5 7.5 0 0 1 14.5 3h21A7.5 7.5 0 0 1 43 10.5v15a7.5 7.5 0 0 1-7.5 7.5H21l-10 8v-9.5A7.5 7.5 0 0 1 7 24.5z" />
            <text className="logo-letter" x="12" y="27">S</text>
            <path className="logo-bolt" d="M33 18 25 28h5l-1 8 9-12h-6z" />
        </svg>
    </span>
);

const Dashboard = () => {
    const { user, token, logout } = useAuth();
    const navigate = useNavigate();
    const [search, setSearch] = useState("");
    const [users, setUsers] = useState([]);
    const [conversations, setConversations] = useState([]);
    const [conversation, setConversation] = useState(null);
    const [messages, setMessages] = useState([]);
    const [text, setText] = useState("");
    const [loadingUsers, setLoadingUsers] = useState(true);
    const [loadingMessages, setLoadingMessages] = useState(false);
    const [error, setError] = useState("");
    const [typingUser, setTypingUser] = useState(false);
    const [showEmoji, setShowEmoji] = useState(false);
    const [uploadingFile, setUploadingFile] = useState(false);
    const fileInputRef = useRef(null);
    const [showGroupModal, setShowGroupModal] = useState(false);
    const [groupName, setGroupName] = useState("");
    const [selectedMembers, setSelectedMembers] = useState([]);
    const [creatingGroup, setCreatingGroup] = useState(false);
    const socketRef = useRef(null);
    const bottomRef = useRef(null);
    const typingTimer = useRef(null);
    const audioContextRef = useRef(null);
    const [unreadTotal, setUnreadTotal] = useState(0);
    const [chatFilter, setChatFilter] = useState("all");
    const [theme, setTheme] = useState(() => localStorage.getItem("s-chat-theme") || "light");


    const playNotificationSound = () => {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const ctx = audioContextRef.current || new AudioContext();
            audioContextRef.current = ctx;
            if (ctx.state === "suspended") ctx.resume();
            const oscillator = ctx.createOscillator();
            const gain = ctx.createGain();
            oscillator.type = "sine";
            oscillator.frequency.setValueAtTime(880, ctx.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.12);
            gain.gain.setValueAtTime(0.0001, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.08, ctx.currentTime + 0.01);
            gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.18);
            oscillator.connect(gain); gain.connect(ctx.destination);
            oscillator.start(); oscillator.stop(ctx.currentTime + 0.18);
        } catch {}
    };

    useEffect(() => { localStorage.setItem("s-chat-theme", theme); }, [theme]);

    const refreshUnreadTotal = (list) => setUnreadTotal((list || []).reduce((sum, item) => sum + Number(item.unreadCount || 0), 0));

    const loadUsers = async () => {
        try {
            setLoadingUsers(true);
            const response = await api.get("/users", { ...auth(token), params: search.trim() ? { search: search.trim() } : {} });
            setUsers(response.data.users || []);
        } catch (err) { setError(err.response?.data?.message || "Unable to load users."); }
        finally { setLoadingUsers(false); }
    };

    const loadConversations = async () => {
        try { const response = await api.get("/conversations", auth(token)); const list = response.data.conversations || []; setConversations(list); refreshUnreadTotal(list); }
        catch (err) { console.error(err); }
    };

    useEffect(() => { const timer = setTimeout(loadUsers, 250); return () => clearTimeout(timer); }, [search, token]);
    useEffect(() => { loadConversations(); }, [token]);

    useEffect(() => {
        if (!token) return;
        const socket = io(SOCKET_URL, { auth: { token } });
        socketRef.current = socket;
        socket.on("new_message", (message) => {
            setMessages((current) => current.some((m) => m._id === message._id) ? current : (conversation?._id === message.conversation ? [...current, message] : current));
            const isMine = message.sender?._id === user?._id;
            const isCurrent = conversation?._id === message.conversation;
            if (!isMine && !isCurrent) playNotificationSound();
            if (!isMine && isCurrent) {
                socket.emit("message_delivered", { conversationId: message.conversation, messageId: message._id });
                api.patch(`/conversations/${message.conversation}/read`, {}, auth(token)).catch(() => {});
            }
            loadConversations();
        });
        socket.on("conversation_updated", () => loadConversations());
        socket.on("typing", ({ conversationId, userId, isTyping }) => {
            if (conversation?._id === conversationId && userId !== user?._id) setTypingUser(isTyping);
        });
        socket.on("user_status", ({ userId, status, lastSeen }) => {
            setUsers((list) => list.map((u) => u._id === userId ? { ...u, status, lastSeen } : u));
            setConversations((list) => list.map((c) => ({ ...c, members: c.members.map((m) => m._id === userId ? { ...m, status, lastSeen } : m) })));
            setConversation((c) => c ? { ...c, members: c.members.map((m) => m._id === userId ? { ...m, status, lastSeen } : m) } : c);
        });
        socket.on("message_delivered", ({ messageId }) => setMessages((list) => list.map((m) => m._id === messageId && m.status !== "read" ? { ...m, status: "delivered" } : m)));
        socket.on("messages_read", ({ conversationId }) => {
            if (conversation?._id === conversationId) setMessages((list) => list.map((m) => m.sender?._id === user?._id ? { ...m, status: "read" } : m));
            loadConversations();
        });
        return () => { if (typingTimer.current) clearTimeout(typingTimer.current); socket.disconnect(); socketRef.current = null; };
    }, [token, conversation?._id, user?._id]);

    useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, typingUser]);

    const openConversation = async (conv) => {
        try {
            setError(""); setLoadingMessages(true); setTypingUser(false); setConversation(conv);
            socketRef.current?.emit("join_conversation", conv._id);
            const response = await api.get(`/conversations/${conv._id}/messages`, auth(token));
            setMessages(response.data.messages || []);
            await api.patch(`/conversations/${conv._id}/read`, {}, auth(token));
            loadConversations();
        } catch (err) { setError(err.response?.data?.message || "Unable to open conversation."); }
        finally { setLoadingMessages(false); }
    };

    const selectUser = async (item) => {
        try {
            setError(""); setLoadingMessages(true); setTypingUser(false);
            const response = await api.post(`/conversations/private/${item._id}`, {}, auth(token));
            await openConversation(response.data.conversation);
        } catch (err) { setError(err.response?.data?.message || "Unable to open conversation."); setLoadingMessages(false); }
    };

    const createGroup = async (event) => {
        event.preventDefault();
        if (!groupName.trim() || selectedMembers.length === 0) return;
        try {
            setCreatingGroup(true); setError("");
            const response = await api.post("/groups", { name: groupName.trim(), memberIds: selectedMembers }, auth(token));
            setShowGroupModal(false); setGroupName(""); setSelectedMembers([]);
            await loadConversations();
            await openConversation(response.data.conversation);
        } catch (err) { setError(err.response?.data?.message || "Unable to create group."); }
        finally { setCreatingGroup(false); }
    };

    const toggleMember = (id) => setSelectedMembers((list) => list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

    const handleTyping = (event) => {
        const value = event.target.value;
        setText(value);
        if (!conversation || !socketRef.current) return;
        socketRef.current.emit("typing", { conversationId: conversation._id, isTyping: value.length > 0 });
        if (typingTimer.current) clearTimeout(typingTimer.current);
        typingTimer.current = setTimeout(() => {
            socketRef.current?.emit("typing", { conversationId: conversation._id, isTyping: false });
        }, 900);
    };

    const sendMessage = async (event) => {
        event?.preventDefault();
        const value = text.trim();
        if (!value || !conversation) return;
        try {
            setText(""); setShowEmoji(false);
            socketRef.current?.emit("typing", { conversationId: conversation._id, isTyping: false });
            await api.post(`/conversations/${conversation._id}/messages`, { text: value, messageType: "text" }, auth(token));
            loadConversations();
        } catch (err) { setError(err.response?.data?.message || "Message could not be sent."); setText(value); }
    };

    const handleFileSelected = async (event) => {
        const file = event.target.files?.[0];
        event.target.value = "";
        if (!file || !conversation) return;
        if (file.size > 50 * 1024 * 1024) { setError("File is too large. Maximum size is 50 MB."); return; }
        try {
            setUploadingFile(true); setError("");
            const formData = new FormData();
            formData.append("file", file);
            const response = await api.post(`/conversations/${conversation._id}/messages/file`, formData, {
                headers: { Authorization: `Bearer ${token}`, "Content-Type": "multipart/form-data" }
            });
            setMessages((list) => list.some((m) => m._id === response.data.message._id) ? list : [...list, response.data.message]);
            loadConversations();
        } catch (err) { setError(err.response?.data?.message || "File upload failed."); }
        finally { setUploadingFile(false); }
    };

    const filteredConversations = useMemo(() => {
        const list = conversations || [];
        if (chatFilter === "unread") return list.filter((item) => Number(item.unreadCount || 0) > 0);
        if (chatFilter === "group") return list.filter((item) => item.type === "group");
        return list;
    }, [conversations, chatFilter]);

    const renderAttachment = (message) => {
        if (!message.fileUrl) return null;
        const url = message.fileUrl;
        const name = message.fileName || "Attachment";
        const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : "";
        const isImage = message.messageType === "image" || ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg"].includes(ext);
        const isVideo = message.messageType === "video" || ["mp4", "webm", "mov", "m4v", "ogg"].includes(ext);
        const isAudio = ["mp3", "wav", "ogg", "m4a", "aac", "flac"].includes(ext);
        const isPdf = ext === "pdf";

        if (isImage) {
            return <a className="attachment-image-link" href={url} target="_blank" rel="noreferrer" title={`Open ${name}`}>
                <img className="chat-image" src={url} alt={name} loading="lazy" onError={(e) => { e.currentTarget.style.display = "none"; }} />
            </a>;
        }
        if (isVideo) {
            return <video className="chat-video" controls preload="metadata" src={url} />;
        }
        if (isAudio) {
            return <div className="chat-audio"><div className="attachment-icon">🎵</div><div className="attachment-info"><strong>{name}</strong><audio controls src={url} /></div></div>;
        }
        if (isPdf) {
            return <div className="pdf-preview-wrap"><iframe className="pdf-preview" src={url} title={name} /><a className="attachment-card" href={url} target="_blank" rel="noreferrer"><span className="attachment-icon">📄</span><span className="attachment-info"><strong>{name}</strong><small>Open / download PDF</small></span><span>↗</span></a></div>;
        }
        return <a className="attachment-card" href={url} target="_blank" rel="noreferrer" download={name}>
            <span className="attachment-icon">{["zip", "rar", "7z", "tar", "gz"].includes(ext) ? "🗜️" : ["doc", "docx", "odt", "rtf"].includes(ext) ? "📝" : ["ppt", "pptx", "odp"].includes(ext) ? "📊" : ["xls", "xlsx", "csv"].includes(ext) ? "📈" : "📎"}</span>
            <span className="attachment-info"><strong>{name}</strong><small>{message.fileSize ? `${(message.fileSize / (1024 * 1024)).toFixed(2)} MB` : "File attachment"}</small></span>
            <span className="attachment-download">⬇</span>
        </a>;
    };

    const privateOther = useMemo(() => conversation?.type === "private" ? conversation.members?.find((m) => m._id !== user?._id) : null, [conversation, user?._id]);
    const conversationTitle = conversation?.type === "group" ? conversation.name : privateOther?.name;
    const conversationSubtitle = conversation?.type === "group" ? `${conversation.members?.length || 0} members` : (privateOther?.status === "online" ? "Online" : "Offline");
    const avatarContent = (person, fallback) => person?.profilePicture ? <img src={person.profilePicture} alt={person.name || "User"} /> : fallback;
    const statusIcon = (message) => message.sender?._id !== user?._id ? null : message.status === "read" ? <span className="message-status read">✓✓</span> : message.status === "delivered" ? <span className="message-status delivered">✓✓</span> : <span className="message-status sent">✓</span>;

    return <div className={`chat-app-shell theme-${theme}`}>
        <header className="app-header">
            <div className="app-brand"><SChatLogo /><span>S Chat</span></div>
            <div className="header-user"><div className="header-avatar">{avatarContent(user, getInitials(user?.name))}</div><div className="header-user-info"><strong>{user?.name}</strong><span><i className="online-dot" /> Online</span></div><div className="header-actions"><button className="theme-toggle-btn" onClick={() => setTheme((value) => value === "light" ? "dark" : "light")} title={`Switch to ${theme === "light" ? "dark" : "light"} mode`} aria-label="Toggle color theme">{theme === "light" ? "🌙" : "☀️"}</button><button className="settings-btn" onClick={() => navigate("/settings")} title="Settings">⚙️</button><button className="logout-btn" onClick={logout}>Logout</button></div></div>
        </header>
        <main className="chat-layout">
            <aside className="users-panel">
                <div className="panel-heading"><div><h1>Messages</h1><p>Chat with people and groups</p></div><button className="new-group-btn" onClick={() => setShowGroupModal(true)}>＋ Group</button></div>
                <div className="search-box"><span>🔍</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search people..." />{search && <button className="clear-search" onClick={() => setSearch("")}>×</button>}</div>
                {error && <div className="panel-error">{error}</div>}
                <div className="chat-filter-bar" role="tablist" aria-label="Filter conversations">
                    {[["all", "All"], ["unread", "Unread"], ["group", "Group"]].map(([value, label]) => (
                        <button key={value} role="tab" aria-selected={chatFilter === value} className={`chat-filter-btn ${chatFilter === value ? "active" : ""}`} onClick={() => setChatFilter(value)}>
                            {label}{value === "unread" && unreadTotal > 0 && <span className="filter-count">{unreadTotal > 99 ? "99+" : unreadTotal}</span>}
                        </button>
                    ))}
                </div>
                {filteredConversations.length > 0 && <div className="sidebar-section-title">Recent chats</div>}
                <div className="users-list conversation-list">
                    {filteredConversations.map((item) => {
                        const other = item.type === "private" ? item.members?.find((m) => m._id !== user?._id) : null;
                        const title = item.type === "group" ? item.name : other?.name || "Private chat";
                        const sub = item.type === "group" ? `${item.members?.length || 0} members` : "Private chat";
                        return <button key={item._id} className={`user-row ${conversation?._id === item._id ? "selected" : ""}`} onClick={() => openConversation(item)}><div className="avatar-wrap"><div className="user-avatar">{item.type === "group" ? "👥" : avatarContent(other, getInitials(title))}</div></div><div className="user-row-info"><strong>{title}</strong><span>{sub}</span></div>{item.unreadCount > 0 && <b className="unread-badge">{item.unreadCount > 99 ? "99+" : item.unreadCount}</b>}</button>;
                    })}
                    {!loadingMessages && filteredConversations.length === 0 && <div className="filter-empty">{chatFilter === "unread" ? "You're all caught up — no unread chats." : "No group conversations yet."}</div>}
                </div>
                {chatFilter === "all" && <><div className="sidebar-section-title people-title">People</div>
                <div className="users-list">
                    {loadingUsers ? <div className="list-state">Loading users...</div> : users.length === 0 ? <div className="empty-users"><div>👥</div><strong>No other users found</strong><span>Register another account to chat.</span></div> : users.map((item) => <button key={item._id} className="user-row" onClick={() => selectUser(item)}><div className="avatar-wrap"><div className="user-avatar">{avatarContent(item, getInitials(item.name))}</div><i className={`status-dot ${item.status === "online" ? "online" : "offline"}`} /></div><div className="user-row-info"><strong>{item.name}</strong><span>{item.status === "online" ? "Online" : "Offline"}</span></div></button>)}
                </div></>}
            </aside>
            <section className="conversation-panel">
                {!conversation ? <div className="welcome-chat"><div className="welcome-illustration" aria-hidden="true"><div className="scene-bubble scene-bubble-left"><span>••</span><i>•••</i></div><div className="scene-phone"><div className="phone-speaker"/><div className="phone-avatar"/><div className="phone-line line-one"/><div className="phone-line line-two"/><div className="phone-chat chat-one">Hello!</div><div className="phone-chat chat-two">Hi 👋</div></div><div className="scene-plane">➤</div><div className="scene-bubble scene-bubble-right">•••</div><div className="scene-laptop"><div className="laptop-camera"/><div className="laptop-chat left-chat"/><div className="laptop-chat right-chat"/><div className="laptop-chat short-chat"/><div className="laptop-base"/></div><div className="scene-spark spark-one">✦</div><div className="scene-spark spark-two">✧</div><div className="scene-plant"><i/><i/><i/><b/></div></div><div className="welcome-content"><div className="welcome-art"><div className="art-bubble art-bubble-one">S</div><div className="art-bubble art-bubble-two">✦</div><div className="art-bolt">ϟ</div><SChatLogo compact /></div><h2>Welcome to S Chat</h2><p>Select a person or group from the left to start chatting.</p><div className="feature-row"><span>⚡ Real-time messages</span><span>👥 Group chat</span><span>🟢 Online status</span></div></div></div> : <>
                    <div className="conversation-header"><div className="conversation-avatar">{conversation.type === "group" ? "👥" : avatarContent(privateOther, getInitials(conversationTitle))}</div><div><h2>{conversationTitle}</h2><p>{conversation.type === "private" && <i className={`status-dot inline ${privateOther?.status === "online" ? "online" : "offline"}`} />}{conversationSubtitle}{typingUser ? " · typing..." : ""}</p></div></div>
                    <div className="messages-area">
                        {loadingMessages ? <div className="list-state">Loading messages...</div> : messages.length === 0 ? <div className="conversation-empty"><div className="empty-chat-icon">👋</div><h2>Start a conversation</h2><p>Send the first message to {conversationTitle}.</p></div> : messages.map((message) => <div key={message._id} className={`message-row ${message.sender?._id === user?._id ? "mine" : "theirs"}`}><div className="message-bubble">{conversation.type === "group" && message.sender?._id !== user?._id && <strong className="group-sender">{message.sender?.name}</strong>}{renderAttachment(message)}{message.text && <div className="message-text">{message.text}</div>}<span className="message-meta">{new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} {statusIcon(message)}</span></div></div>)}
                        {typingUser && <div className="typing-bubble">Someone is typing…</div>}<div ref={bottomRef} />
                    </div>
                    <form className="message-composer" onSubmit={sendMessage}><input ref={fileInputRef} type="file" className="hidden-file-input" onChange={handleFileSelected} accept=".jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.mov,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.zip,.rar" /><button type="button" className="icon-btn" onClick={() => fileInputRef.current?.click()} title="Attach file" disabled={uploadingFile}>{uploadingFile ? "⏳" : "📎"}</button><div className="emoji-wrap"><button type="button" className="icon-btn" onClick={() => setShowEmoji((v) => !v)}>😊</button>{showEmoji && <div className="emoji-picker">{emojis.map((emoji) => <button type="button" key={emoji} onClick={() => setText((v) => v + emoji)}>{emoji}</button>)}</div>}</div><input value={text} onChange={handleTyping} placeholder="Type a message..." /><button className="send-btn" type="submit" disabled={!text.trim()}>➤</button></form>
                </>}
            </section>
        </main>
        {showGroupModal && <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setShowGroupModal(false)}><form className="group-modal" onSubmit={createGroup}><div className="modal-header"><div><h2>Create group</h2><p>Add people and start a group conversation.</p></div><button type="button" className="modal-close" onClick={() => setShowGroupModal(false)}>×</button></div><label className="modal-label">Group name<input value={groupName} onChange={(e) => setGroupName(e.target.value)} placeholder="e.g. Project Team" maxLength={100} /></label><div className="modal-label">Select members <span className="selected-count">{selectedMembers.length} selected</span></div><div className="member-picker">{users.map((item) => <label className={`member-option ${selectedMembers.includes(item._id) ? "checked" : ""}`} key={item._id}><input type="checkbox" checked={selectedMembers.includes(item._id)} onChange={() => toggleMember(item._id)} /><span className="user-avatar small">{avatarContent(item, getInitials(item.name))}</span><span><strong>{item.name}</strong><small>{item.email}</small></span></label>)}</div><div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setShowGroupModal(false)}>Cancel</button><button className="primary-settings-btn" disabled={creatingGroup || !groupName.trim() || selectedMembers.length === 0}>{creatingGroup ? "Creating..." : "Create group"}</button></div></form></div>}
    </div>;
};
export default Dashboard;
