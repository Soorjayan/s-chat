# S Chat Frontend

React + Vite client for S Chat.

## Local development

```bash
npm install
npm run dev
```

If the backend is not at `http://localhost:5000`, create a `.env` file using `.env.example` and set `VITE_API_URL` (including `/api`) and `VITE_SOCKET_URL` (origin only).

## Vercel deployment

Set Vercel Root Directory to `frontend`, Build Command to `npm run build`, and Output Directory to `dist`. Configure `VITE_API_URL` and `VITE_SOCKET_URL` with your Render backend URL, then redeploy. `vercel.json` includes a single-page-app route fallback.
